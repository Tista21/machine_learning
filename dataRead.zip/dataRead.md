```python
import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split


import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline

from numpy.polynomial import Polynomial
from sklearn.preprocessing import RobustScaler, StandardScaler
from datetime import datetime
import math
from xgboost import XGBRegressor
import xgboost as xgb
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import Ridge, RidgeCV, Lasso, LassoCV, LinearRegression
from sklearn.tree import DecisionTreeRegressor


from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.model_selection import cross_val_score, KFold, RepeatedKFold, learning_curve
from sklearn.metrics import accuracy_score, f1_score, r2_score, precision_score, recall_score, classification_report, confusion_matrix

```


```python
df = pd.read_csv('../tista/Downloads/realestate/real/Real estate1.csv')

df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>No</th>
      <th>X1 transaction date</th>
      <th>X2 house age</th>
      <th>X3 distance to the nearest MRT station</th>
      <th>X4 number of convenience stores</th>
      <th>X5 latitude</th>
      <th>X6 longitude</th>
      <th>Y house price of unit area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2012.917</td>
      <td>32.0</td>
      <td>84.87882</td>
      <td>10</td>
      <td>24.98298</td>
      <td>121.54024</td>
      <td>37.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2012.917</td>
      <td>19.5</td>
      <td>306.59470</td>
      <td>9</td>
      <td>24.98034</td>
      <td>121.53951</td>
      <td>42.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2013.583</td>
      <td>13.3</td>
      <td>561.98450</td>
      <td>5</td>
      <td>24.98746</td>
      <td>121.54391</td>
      <td>47.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2013.500</td>
      <td>13.3</td>
      <td>561.98450</td>
      <td>5</td>
      <td>24.98746</td>
      <td>121.54391</td>
      <td>54.8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2012.833</td>
      <td>5.0</td>
      <td>390.56840</td>
      <td>5</td>
      <td>24.97937</td>
      <td>121.54245</td>
      <td>43.1</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.drop('No', inplace=True, axis=1)


df.columns = ['transaction date', 'house age', 'distance to the nearest MRT station', 'number of convenience stores', 'latitude', 'longitude', 'house price of unit area']
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transaction date</th>
      <th>house age</th>
      <th>distance to the nearest MRT station</th>
      <th>number of convenience stores</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>house price of unit area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2012.917</td>
      <td>32.0</td>
      <td>84.87882</td>
      <td>10</td>
      <td>24.98298</td>
      <td>121.54024</td>
      <td>37.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2012.917</td>
      <td>19.5</td>
      <td>306.59470</td>
      <td>9</td>
      <td>24.98034</td>
      <td>121.53951</td>
      <td>42.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2013.583</td>
      <td>13.3</td>
      <td>561.98450</td>
      <td>5</td>
      <td>24.98746</td>
      <td>121.54391</td>
      <td>47.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2013.500</td>
      <td>13.3</td>
      <td>561.98450</td>
      <td>5</td>
      <td>24.98746</td>
      <td>121.54391</td>
      <td>54.8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2012.833</td>
      <td>5.0</td>
      <td>390.56840</td>
      <td>5</td>
      <td>24.97937</td>
      <td>121.54245</td>
      <td>43.1</td>
    </tr>
  </tbody>
</table>
</div>




```python
train_data, test_data = train_test_split(df, test_size=0.3, random_state=2)
```


```python
print("Train set size:",len(train_data))
print("Test set size:",len(test_data))
```

    Train set size: 289
    Test set size: 125
    


```python
train_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transaction date</th>
      <th>house age</th>
      <th>distance to the nearest MRT station</th>
      <th>number of convenience stores</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>house price of unit area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>237</th>
      <td>2013.167</td>
      <td>13.0</td>
      <td>732.8528</td>
      <td>0</td>
      <td>24.97668</td>
      <td>121.52518</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>146</th>
      <td>2012.750</td>
      <td>0.0</td>
      <td>185.4296</td>
      <td>0</td>
      <td>24.97110</td>
      <td>121.53170</td>
      <td>52.2</td>
    </tr>
    <tr>
      <th>320</th>
      <td>2012.750</td>
      <td>13.5</td>
      <td>4197.3490</td>
      <td>0</td>
      <td>24.93885</td>
      <td>121.50383</td>
      <td>18.6</td>
    </tr>
    <tr>
      <th>150</th>
      <td>2013.250</td>
      <td>35.8</td>
      <td>170.7311</td>
      <td>7</td>
      <td>24.96719</td>
      <td>121.54269</td>
      <td>48.5</td>
    </tr>
    <tr>
      <th>198</th>
      <td>2013.083</td>
      <td>34.0</td>
      <td>157.6052</td>
      <td>7</td>
      <td>24.96628</td>
      <td>121.54196</td>
      <td>39.1</td>
    </tr>
  </tbody>
</table>
</div>




```python
train_data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 289 entries, 237 to 168
    Data columns (total 7 columns):
     #   Column                               Non-Null Count  Dtype  
    ---  ------                               --------------  -----  
     0   transaction date                     289 non-null    float64
     1   house age                            289 non-null    float64
     2   distance to the nearest MRT station  289 non-null    float64
     3   number of convenience stores         289 non-null    int64  
     4   latitude                             289 non-null    float64
     5   longitude                            289 non-null    float64
     6   house price of unit area             289 non-null    float64
    dtypes: float64(6), int64(1)
    memory usage: 18.1 KB
    


```python
train_data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transaction date</th>
      <th>house age</th>
      <th>distance to the nearest MRT station</th>
      <th>number of convenience stores</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>house price of unit area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>289.000000</td>
      <td>289.000000</td>
      <td>289.000000</td>
      <td>289.000000</td>
      <td>289.000000</td>
      <td>289.000000</td>
      <td>289.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2013.140159</td>
      <td>17.077163</td>
      <td>1020.394663</td>
      <td>4.290657</td>
      <td>24.968966</td>
      <td>121.533996</td>
      <td>38.317993</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.279693</td>
      <td>11.251242</td>
      <td>1235.307204</td>
      <td>2.949567</td>
      <td>0.012215</td>
      <td>0.014981</td>
      <td>13.037956</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2012.667000</td>
      <td>0.000000</td>
      <td>23.382840</td>
      <td>0.000000</td>
      <td>24.932930</td>
      <td>121.475160</td>
      <td>7.600000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2012.917000</td>
      <td>8.300000</td>
      <td>279.172600</td>
      <td>2.000000</td>
      <td>24.962990</td>
      <td>121.529840</td>
      <td>28.500000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2013.167000</td>
      <td>15.400000</td>
      <td>492.231300</td>
      <td>5.000000</td>
      <td>24.971100</td>
      <td>121.539170</td>
      <td>39.400000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2013.417000</td>
      <td>26.600000</td>
      <td>1360.139000</td>
      <td>6.000000</td>
      <td>24.977440</td>
      <td>121.543480</td>
      <td>47.100000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2013.583000</td>
      <td>43.800000</td>
      <td>6396.283000</td>
      <td>10.000000</td>
      <td>25.014590</td>
      <td>121.566270</td>
      <td>78.300000</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig, ax = plt.subplots(2, 3, figsize=(14, 10))
ax = ax.flatten()

sns.set()
sns.lineplot(data=train_data, x="transaction date", y="house price of unit area", ax=ax[0])
ax[0].set_title("Price of Unit Area vs. Transaction Date")

sns.lineplot(data=train_data, x="house age", y="house price of unit area", ax=ax[1])
ax[1].set_title("Price of Unit Area vs. House Age")

sns.lineplot(data=train_data, x="distance to the nearest MRT station", y="house price of unit area", ax=ax[2])
ax[2].set_title("Price of Unit Area vs. Distance to the nearest MRT station")

sns.lineplot(data=train_data, x="number of convenience stores", y="house price of unit area", ax=ax[3])
ax[3].set_title("Price of Unit Area vs. no. of Convenience Stores")

sns.lineplot(data=train_data, x="latitude", y="house price of unit area", ax=ax[4])
ax[4].set_title("Price of Unit Area vs. Latitude")

sns.lineplot(data=train_data, x="longitude", y="house price of unit area", ax=ax[5])
ax[5].set_title("Price of Unit Area vs. Longitude")

# set the spacing between subplots
plt.subplots_adjust(left=0.1,
                    bottom=0, 
                    right=0.9, 
                    top=1, 
                    wspace=0.4, 
                    hspace=0.4)
plt.show();
```


    
![png](output_8_0.png)
    



```python
#Preparation
```


```python
fig = plt.figure(figsize=(26,26))
for index,col in enumerate(train_data):
    plt.subplot(6,3,index+1)
    sns.histplot(train_data.loc[:,col].dropna(), kde=True, stat="density", linewidth=0.5);
fig.tight_layout(pad=1.0);
```


    
![png](output_10_0.png)
    



```python
fig = plt.figure(figsize=(14,15))
for index,col in enumerate(train_data):
    plt.subplot(6,3,index+1)
    sns.boxplot(y=col, data=train_data.dropna())
    plt.grid()
fig.tight_layout(pad=1.0)
```


    
![png](output_11_0.png)
    



```python
train_data = train_data[train_data['house price of unit area']<80]
train_data = train_data[train_data['distance to the nearest MRT station']<3000]
train_data = train_data[train_data['longitude']>121.50]
```


```python
fig = plt.figure(figsize=(26,26))
for index,col in enumerate(train_data):
    plt.subplot(6,3,index+1)
    sns.histplot(train_data.loc[:,col].dropna(), kde=True, stat="density", linewidth=0.5);
fig.tight_layout(pad=1.0);
```


    
![png](output_13_0.png)
    



```python
numeric_train = train_data
correlation = numeric_train.corr()
correlation[['house price of unit area']].sort_values(['house price of unit area'], ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>house price of unit area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>house price of unit area</th>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>number of convenience stores</th>
      <td>0.486177</td>
    </tr>
    <tr>
      <th>latitude</th>
      <td>0.422554</td>
    </tr>
    <tr>
      <th>longitude</th>
      <td>0.373205</td>
    </tr>
    <tr>
      <th>transaction date</th>
      <td>0.059678</td>
    </tr>
    <tr>
      <th>house age</th>
      <td>-0.233610</td>
    </tr>
    <tr>
      <th>distance to the nearest MRT station</th>
      <td>-0.664616</td>
    </tr>
  </tbody>
</table>
</div>




```python
corr = train_data.corr()
sns.heatmap(corr, cmap = 'YlGnBu', annot= False, linewidths=.5);
```


    
![png](output_15_0.png)
    



```python
train_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transaction date</th>
      <th>house age</th>
      <th>distance to the nearest MRT station</th>
      <th>number of convenience stores</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>house price of unit area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>237</th>
      <td>2013.167</td>
      <td>13.0</td>
      <td>732.8528</td>
      <td>0</td>
      <td>24.97668</td>
      <td>121.52518</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>146</th>
      <td>2012.750</td>
      <td>0.0</td>
      <td>185.4296</td>
      <td>0</td>
      <td>24.97110</td>
      <td>121.53170</td>
      <td>52.2</td>
    </tr>
    <tr>
      <th>150</th>
      <td>2013.250</td>
      <td>35.8</td>
      <td>170.7311</td>
      <td>7</td>
      <td>24.96719</td>
      <td>121.54269</td>
      <td>48.5</td>
    </tr>
    <tr>
      <th>198</th>
      <td>2013.083</td>
      <td>34.0</td>
      <td>157.6052</td>
      <td>7</td>
      <td>24.96628</td>
      <td>121.54196</td>
      <td>39.1</td>
    </tr>
    <tr>
      <th>262</th>
      <td>2012.917</td>
      <td>15.9</td>
      <td>289.3248</td>
      <td>5</td>
      <td>24.98203</td>
      <td>121.54348</td>
      <td>53.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
dfs = [train_data, test_data]
data = pd.concat(dfs)

```


```python
from yellowbrick.datasets import load_concrete
from yellowbrick.regressor import ResidualsPlot
```


```python
X=data.drop('house price of unit area',axis=1)
y=data['house price of unit area']
```


```python
transformer = StandardScaler().fit(X)
X_prep = transformer.transform(X)
```


```python

polynomial_converter = PolynomialFeatures(degree=2, include_bias=False)


poly_features = polynomial_converter.fit(X_prep)
poly_features = polynomial_converter.transform(X_prep)

poly_features.shape

```




    (389, 27)




```python
#split of train and test dataset
```


```python
X_train, X_test, y_train, y_test = train_test_split(poly_features, y, test_size=0.2, random_state=1)

X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.25, random_state=1)
```


```python
model_poly = LinearRegression()
model_poly.fit(X_train, y_train)
```




    LinearRegression()




```python
pred_train_poly = model_poly.predict(X_train)

r2_train_poly = r2_score(y_train, pred_train_poly)
mse_train_poly = mean_squared_error(y_train, pred_train_poly)
rmse_train_poly = np.sqrt(mse_train_poly)
mae_train_poly = mean_absolute_error(y_train, pred_train_poly)
```


```python
pred_val_poly = model_poly.predict(X_val)

r2_val_poly = r2_score(y_val, pred_val_poly)
mse_val_poly = mean_squared_error(y_val, pred_val_poly)
rmse_val_poly = np.sqrt(mse_val_poly)
mae_val_poly = mean_absolute_error(y_val, pred_val_poly)
```


```python
pd.DataFrame({'Validation':  [r2_val_poly, mse_val_poly, rmse_val_poly, mae_val_poly],
               'Training': [r2_train_poly, mse_train_poly, rmse_train_poly, mae_train_poly],
             },
              index=['R2', 'MSE', 'RMSE', 'MAE'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Validation</th>
      <th>Training</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>R2</th>
      <td>0.652599</td>
      <td>0.634680</td>
    </tr>
    <tr>
      <th>MSE</th>
      <td>64.127163</td>
      <td>61.356473</td>
    </tr>
    <tr>
      <th>RMSE</th>
      <td>8.007944</td>
      <td>7.833037</td>
    </tr>
    <tr>
      <th>MAE</th>
      <td>5.820962</td>
      <td>5.060860</td>
    </tr>
  </tbody>
</table>
</div>




```python
pred_test_poly = model_poly.predict(X_test)

r2_test_poly = r2_score(y_test, pred_test_poly)
mse_test_poly = mean_squared_error(y_test, pred_test_poly)
rmse_test_poly = np.sqrt(mse_test_poly)
mae_test_poly = mean_absolute_error(y_test, pred_test_poly)

print('R2 Score: ', r2_test_poly)
print('MSE: ', mse_test_poly)
print('RMSE: ', rmse_test_poly)
print('MAE: ', mae_test_poly)
```

    R2 Score:  0.7396941504104604
    MSE:  39.08219404069756
    RMSE:  6.251575324723966
    MAE:  5.050509169077719
    


```python
mean_poly=np.mean(pred_test_poly)
print(mean_poly)
```

    39.41102921842082
    


```python
std_poly=np.std(pred_test_poly)
print(std_poly)
```

    10.12796482194187
    


```python
visualizer = ResidualsPlot(model_poly, hist=False, qqplot=True)
visualizer.fit(X_train, y_train)
visualizer.score(X_test, y_test)
visualizer.show();
```


    
![png](output_31_0.png)
    



```python
pd.DataFrame({'Y_Test': y_test,'Y_Pred':pred_test_poly, 'Residuals':(y_test-pred_test_poly) }).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Y_Test</th>
      <th>Y_Pred</th>
      <th>Residuals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>120</th>
      <td>31.3</td>
      <td>41.367766</td>
      <td>-10.067766</td>
    </tr>
    <tr>
      <th>353</th>
      <td>31.3</td>
      <td>28.720681</td>
      <td>2.579319</td>
    </tr>
    <tr>
      <th>410</th>
      <td>50.0</td>
      <td>52.662491</td>
      <td>-2.662491</td>
    </tr>
    <tr>
      <th>259</th>
      <td>28.8</td>
      <td>27.282596</td>
      <td>1.517404</td>
    </tr>
    <tr>
      <th>31</th>
      <td>25.0</td>
      <td>36.475085</td>
      <td>-11.475085</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.scatter(y_test, pred_test_poly)
plt.xlabel('Real')
plt.ylabel('Pred')
plt.title('Polynomial Reg pred against real')
plt.show()
```


    
![png](output_33_0.png)
    



```python
model = DecisionTreeRegressor()
model.fit(X_train, y_train)
```




    DecisionTreeRegressor()




```python
pred_train = model.predict(X_train)

r2_train = r2_score(y_train, pred_train)
mse_train = mean_squared_error(y_train, pred_train)
rmse_train = np.sqrt(mse_train)
mae_train = mean_absolute_error(y_train, pred_train)
```


```python
pred_val = model.predict(X_val)

r2_val = r2_score(y_val, pred_val)
mse_val = mean_squared_error(y_val, pred_val)
rmse_val = np.sqrt(mse_val)
mae_val = mean_absolute_error(y_val, pred_val)
```


```python
pd.DataFrame({'Validation':  [r2_val, mse_val, rmse_val, mae_val],
               'Training': [r2_train, mse_train, rmse_train, mae_train],
             },
              index=['R2', 'MSE', 'RMSE', 'MAE'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Validation</th>
      <th>Training</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>R2</th>
      <td>-0.209568</td>
      <td>0.997880</td>
    </tr>
    <tr>
      <th>MSE</th>
      <td>223.275673</td>
      <td>0.356116</td>
    </tr>
    <tr>
      <th>RMSE</th>
      <td>14.942412</td>
      <td>0.596754</td>
    </tr>
    <tr>
      <th>MAE</th>
      <td>8.114744</td>
      <td>0.099142</td>
    </tr>
  </tbody>
</table>
</div>




```python
pred_test = model.predict(X_test)

r2_test = r2_score(y_test, pred_test)
mse_test = mean_squared_error(y_test, pred_test)
rmse_test = np.sqrt(mse_test)
mae_test = mean_absolute_error(y_test, pred_test)

print('R2 Score: ', r2_test)
print('MSE: ', mse_test)
print('RMSE: ', rmse_test)
print('MAE: ', mae_test)
```

    R2 Score:  0.20754390166647652
    MSE:  118.97897435897437
    RMSE:  10.90774836338712
    MAE:  6.641025641025641
    


```python
mean_test=np.mean(pred_test)
print(mean_test)
```

    39.11474358974359
    


```python
std_test=np.std(pred_test)
print(std_test)
```

    14.257110481904393
    


```python
visualizer = ResidualsPlot(model, hist=False, qqplot=True)
visualizer.fit(X_train, y_train)
visualizer.score(X_test, y_test)
visualizer.show();
```


    
![png](output_41_0.png)
    



```python
pd.DataFrame({'Y_Test': y_test,'Y_Pred':pred_test, 'Residuals':(y_test-pred_test) }).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Y_Test</th>
      <th>Y_Pred</th>
      <th>Residuals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>120</th>
      <td>31.3</td>
      <td>38.9</td>
      <td>-7.6</td>
    </tr>
    <tr>
      <th>353</th>
      <td>31.3</td>
      <td>30.7</td>
      <td>0.6</td>
    </tr>
    <tr>
      <th>410</th>
      <td>50.0</td>
      <td>53.5</td>
      <td>-3.5</td>
    </tr>
    <tr>
      <th>259</th>
      <td>28.8</td>
      <td>23.0</td>
      <td>5.8</td>
    </tr>
    <tr>
      <th>31</th>
      <td>25.0</td>
      <td>53.3</td>
      <td>-28.3</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.scatter(y_test, pred_test)
plt.xlabel('Real')
plt.ylabel('Pred')
plt.title('Polynomial Reg pred against real')
plt.show()
```


    
![png](output_43_0.png)
    



```python
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
```


```python
forest_model = RandomForestRegressor(random_state=3)
forest_model.fit(X_train, y_train)

```




    RandomForestRegressor(random_state=3)




```python
predi_train = forest_model.predict(X_train)

r2_train_for = r2_score(y_train, predi_train)
mse_train_for = mean_squared_error(y_train, predi_train)
rmse_train_for = np.sqrt(mse_train_for)
mae_train_for = mean_absolute_error(y_train, predi_train)
```


```python
pred_val_for = forest_model.predict(X_val)
r2_val_for = r2_score(y_val, pred_val_for)
mse_val_for = mean_squared_error(y_val, pred_val_for)
rmse_val_for = np.sqrt(mse_val)
mae_val_for = mean_absolute_error(y_val, pred_val_for)
```


```python
pd.DataFrame({'Validation':  [r2_val_for, mse_val_for, rmse_val_for, mae_val_for],
               'Training': [r2_train_for, mse_train_for, rmse_train_for, mae_train_for],
             },
              index=['R2', 'MSE', 'RMSE', 'MAE'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Validation</th>
      <th>Training</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>R2</th>
      <td>0.613121</td>
      <td>0.939819</td>
    </tr>
    <tr>
      <th>MSE</th>
      <td>71.414463</td>
      <td>10.107603</td>
    </tr>
    <tr>
      <th>RMSE</th>
      <td>15.689360</td>
      <td>3.179246</td>
    </tr>
    <tr>
      <th>MAE</th>
      <td>5.333778</td>
      <td>1.946395</td>
    </tr>
  </tbody>
</table>
</div>




```python
pred_test_for = forest_model.predict(X_test)

r2_test_for = r2_score(y_test, pred_test_for)
mse_test_for = mean_squared_error(y_test, pred_test_for)
rmse_test_for = np.sqrt(mse_test)
mae_test_for = mean_absolute_error(y_test, pred_test_for)

print('R2 Score: ', r2_test_for)
print('MSE: ', mse_test_for)
print('RMSE: ', rmse_test_for)
print('MAE: ', mae_test_for)
```

    R2 Score:  0.7344486168676747
    MSE:  39.869755903365665
    RMSE:  10.938077457283729
    MAE:  4.8356417277167285
    


```python
mean_for=np.mean(pred_test_for)
print(mean_for)
```

    39.641413522588515
    


```python
std_for=np.std(pred_test_for)
print(std_for)
```

    10.802507157348355
    


```python
visualizer = ResidualsPlot(forest_model, hist=False, qqplot=True)
visualizer.fit(X_train, y_train)
visualizer.score(X_test, y_test)
visualizer.show();
```


    
![png](output_52_0.png)
    



```python
pd.DataFrame({'Y_Test': y_test,'Y_Pred':pred_test_for, 'Residuals':(y_test-pred_test_for) }).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Y_Test</th>
      <th>Y_Pred</th>
      <th>Residuals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>120</th>
      <td>31.3</td>
      <td>41.064000</td>
      <td>-9.764000</td>
    </tr>
    <tr>
      <th>353</th>
      <td>31.3</td>
      <td>29.215000</td>
      <td>2.085000</td>
    </tr>
    <tr>
      <th>410</th>
      <td>50.0</td>
      <td>53.402000</td>
      <td>-3.402000</td>
    </tr>
    <tr>
      <th>259</th>
      <td>28.8</td>
      <td>30.205667</td>
      <td>-1.405667</td>
    </tr>
    <tr>
      <th>31</th>
      <td>25.0</td>
      <td>42.028000</td>
      <td>-17.028000</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.scatter(y_test, pred_test_for)
plt.xlabel('Real')
plt.ylabel('Pred')
plt.title('Polynomial Reg pred against real')
plt.show()
```


    
![png](output_54_0.png)
    



```python
from xgboost import XGBRegressor


```


```python
my_model = XGBRegressor()
my_model.fit(X_train, y_train)
```




    XGBRegressor(base_score=None, booster=None, callbacks=None,
                 colsample_bylevel=None, colsample_bynode=None,
                 colsample_bytree=None, early_stopping_rounds=None,
                 enable_categorical=False, eval_metric=None, feature_types=None,
                 gamma=None, gpu_id=None, grow_policy=None, importance_type=None,
                 interaction_constraints=None, learning_rate=None, max_bin=None,
                 max_cat_threshold=None, max_cat_to_onehot=None,
                 max_delta_step=None, max_depth=None, max_leaves=None,
                 min_child_weight=None, missing=nan, monotone_constraints=None,
                 n_estimators=100, n_jobs=None, num_parallel_tree=None,
                 predictor=None, random_state=None, ...)




```python
predic_train = my_model.predict(X_train)

r2_train_xgb = r2_score(y_train, predic_train)
mse_train_xgb = mean_squared_error(y_train, predic_train)
rmse_train_xgb = np.sqrt(mse_train_xgb)
mae_train_xgb = mean_absolute_error(y_train, predic_train)
```


```python
predic_val_xgb = my_model.predict(X_val)

r2_val_xgb = r2_score(y_val, predic_val_xgb)
mse_val_xgb = mean_squared_error(y_val, predic_val_xgb)
rmse_val_xgb = np.sqrt(mse_val_xgb)
mae_val_xgb = mean_absolute_error(y_val, predic_val_xgb)
```


```python
pd.DataFrame({'Validation':  [r2_val_xgb, mse_val_xgb, rmse_val_xgb, mae_val_xgb],
               'Training': [r2_train_xgb, mse_train_xgb, rmse_train_xgb, mae_train_xgb],
             },
              index=['R2', 'MSE', 'RMSE', 'MAE'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Validation</th>
      <th>Training</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>R2</th>
      <td>0.600916</td>
      <td>0.997880</td>
    </tr>
    <tr>
      <th>MSE</th>
      <td>73.667464</td>
      <td>0.356120</td>
    </tr>
    <tr>
      <th>RMSE</th>
      <td>8.582975</td>
      <td>0.596758</td>
    </tr>
    <tr>
      <th>MAE</th>
      <td>5.711356</td>
      <td>0.100461</td>
    </tr>
  </tbody>
</table>
</div>




```python
pred_test_xgb = my_model.predict(X_test)

r2_test_xgb = r2_score(y_test, pred_test_xgb)
mse_test_xgb = mean_squared_error(y_test, pred_test_xgb)
rmse_test_xgb = np.sqrt(mse_test)
mae_test_xgb = mean_absolute_error(y_test, pred_test_xgb)

print('R2 Score: ', r2_test_xgb)
print('MSE: ', mse_test_xgb)
print('RMSE: ', rmse_test_xgb)
print('MAE: ', mae_test_xgb)
```

    R2 Score:  0.6819043456720641
    MSE:  47.75872730309407
    RMSE:  10.938077457283729
    MAE:  5.201591569949418
    


```python
mean_xgb=np.mean(pred_test_xgb)
print(mean_xgb)
```

    39.395058
    


```python
std_xgb=np.std(pred_test_xgb)
print(std_xgb)
```

    11.408933
    


```python
visualizer = ResidualsPlot(my_model, hist=False, qqplot=True)
visualizer.fit(X_train, y_train)
visualizer.score(X_test, y_test)
visualizer.show();
```


    
![png](output_63_0.png)
    



```python
pd.DataFrame({'Y_Test': y_test,'Y_Pred':pred_test_xgb, 'Residuals':(y_test-pred_test_xgb) }).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Y_Test</th>
      <th>Y_Pred</th>
      <th>Residuals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>120</th>
      <td>31.3</td>
      <td>39.637165</td>
      <td>-8.337165</td>
    </tr>
    <tr>
      <th>353</th>
      <td>31.3</td>
      <td>30.676428</td>
      <td>0.623572</td>
    </tr>
    <tr>
      <th>410</th>
      <td>50.0</td>
      <td>53.500797</td>
      <td>-3.500797</td>
    </tr>
    <tr>
      <th>259</th>
      <td>28.8</td>
      <td>23.301985</td>
      <td>5.498015</td>
    </tr>
    <tr>
      <th>31</th>
      <td>25.0</td>
      <td>39.957886</td>
      <td>-14.957886</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.scatter(y_test, pred_test_xgb)
plt.xlabel('Real')
plt.ylabel('Pred')
plt.title('Polynomial Reg pred against real')
plt.show()
```


    
![png](output_65_0.png)
    



```python

```


```python

```
